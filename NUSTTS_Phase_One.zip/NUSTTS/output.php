<?php 
	phpinfo();
?>