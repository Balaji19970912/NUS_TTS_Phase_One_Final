<?php
    include('security.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NUS TTS System | Parent Company List</title>
    <link rel="icon" href="img/social-square-n-blue.png">
    <link
      rel="stylesheet"
      href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css"
    />
    <link rel="stylesheet" type="text/css" href="css/style.css" />

    <style>

        #DataTables_Table_0_wrapper {
            position: absolute;
            width: 87%;
            margin: 80px 0 0 360px;
        }

       #myTable_wrapper {
            position: absolute;
            width: 76%;
            /* margin: 0px 0 0 300px; */
            left: 20%;
        }

      
        table {
            border: 2px solid #D2DDEC;
            border-radius: 6px;
            width: 76%;
            margin: 10px 300px;
            /* height: 70vh; */
        }
       
        table th {
            color: #343a40;
            background: #F9FBFD;
        }
        table.myTable thead th {
	        border-bottom: 1px solid #CED4DA !important;
        }
        table td {
            color: #12263F;
            font-size: 13px;
            border-bottom: 1px solid #CED4DA;
        }
        table.dataTable.no-footer {
            /* border-bottom: 2px solid #D2DDEC !important; */
            border-bottom: none !important;
        }

        table tbody td a {
            color: #345DA6;
            font-size: 14px;
        }

        .parentdatas{
            text-decoration: none;
        }
        .parent {
            text-align:left;
        }
        .clientfrs {
            margin: 40px 0 0 20%;
            position: relative;
            top: 8%;
            font-weight: 600;
            font-size: 20px;
            color:#345DA6;
        }
        .viewclient {
                color: #fff;
              
                padding:5px 10px;
                border-radius:25px;
        }

        table.dataTable thead > tr > th.sorting_asc::before, 
        table.dataTable thead > tr > th.sorting_desc::after {
            opacity: 1;
        }
        td {
            background: white;
        }
        .viewIcon {
            width: 24px;
            height:24px;
            /* background-color: #345DA6; */
        }
    </style>
</head>
<body>
<div class="main">
        <div class="menu">

            <?php
                include('sidebar.php');
            ?>
        </div>
    <div>
        <br>
        <br>
        <pre><p><a href="addhome.php" class="clientfrs" ><?php echo $_GET['id']?></a></p></pre>
        <br>
<table class="myTable" id ="myTable" >
		<thead class="tableheadings" style="height:40px">
			<!-- <tr> -->
			<th class="parent">Client Company</th>
            <th class="parent">Country</th>
            <th class="parent"></th>
			<!-- </tr> -->
		</thead>
		<tbody>
        <?php
                include('dbconn.php');

                
                if($_SESSION['role'] == 'Client company'){
                    // $res = $_SESSION['client'];
                    // echo "<script>var myres='$res'.split(',');alert(myres[0]);</script>";
                    $user ="AND clientcompany ='".$_SESSION['client']."'";
                    // echo '<h1>'.$_SESSION['client'].'</h1>';
                    // echo '<h1>Im Client</h1>';
                }else{
                    $user ="AND parentcompany ='".$_GET['id']."'";
                }
                
                $sql = "SELECT * FROM clientcompanydata WHERE 1 ".$user."";

                // echo '<h1>'.$sql.'</h1>';
                $result = mysqli_query($conn,$sql);

                while($row = mysqli_fetch_assoc($result)) {
        ?>
			
                <tr style="height:40px">       
                    <!-- <td><a href=""><a></td> -->
                    <td><a href="listsupplycontract.php?id=<?=$row['id']?>&clinet=<?=$row['clientcompany']?>&parent=<?=$row['parentcompany']?>"><?php echo $row['clientcompany']; ?></a></td>
                    <td><a><?php echo $row['country']; ?></a></td>
                    <td><a class ="viewclient" href="listsupplycontract.php?id=<?=$row['id']?>&clinet=<?=$row['clientcompany']?>&parent=<?=$row['parentcompany']?>"><img src="img/views3.svg" alt="" class ="viewIcon"></a></td>

                </tr>
			<?php }?>
           
		</tbody>
	</table>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js" ></script>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js">
    </script>
    <script>
        $(document).ready( function () {
         $('#myTable').DataTable();
        } );
    </script>
     <?php
        include('hoverinclude/hoverhome.php');
    ?>
    </body>
</html>
