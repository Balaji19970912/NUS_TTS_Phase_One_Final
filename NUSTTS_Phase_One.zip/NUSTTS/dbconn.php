<?php

$sername = "localhost";
$user = "root";
$pass = "NUStradetrack@839";
$dbname = "nus";
//i2253940_wp1

$conn = mysqli_connect($sername, $user, $pass, $dbname);

if(!$conn) {
    echo "Connection Failed...!";
}

?>